Demonstrate how to use simple objects to encapsulte hardware details.

Setup
1. Connect nucleo-f767 board to PC.
2. Open virtual comm port.
3. Keep setting as 9600,7,N,1
4. Observe banner "Hello World on Terminal"